module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DATABASE: "polibatam1"
};